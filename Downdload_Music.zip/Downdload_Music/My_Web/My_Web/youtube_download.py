import youtube_dl
import xlwings as xw
import re
import os



def DownloadFunction(links,output_folder,audio_only=True):

    '''
    :param links: urls to download
    :param audio_only: defaut=true
    :param output_folder: folder to download audio
    :return: dictionary author:titre
    '''

    ydl=youtube_dl.YoutubeDL()
    url=links
    r=None
    audio_folder=os.path.join(output_folder,'Audio/%(title)s.mp3')
    video_folder=os.path.join(output_folder,'Video/%(title)s.%(ext)s')

    if audio_only:
        options={'format': 'bestaudio/best',
      'extractaudio' : True,  # only keep the audio
      'audioformat' : "mp3",  # convert to mp3
      'outtmpl': audio_folder,
      'noplaylist' : True,    # only download single song, not plaist}
                 }
    else:
        options={#'format': 'bestaudio/best',
      #'extractaudio' : True,  # only keep the audio
      #'audioformat' : "mp3",  # convert to mp3
      'outtmpl': video_folder,
      'noplaylist' : True,    # only download single song, not plaist}
                 }
    ydl=youtube_dl.YoutubeDL(options)
    ydl.download(url)




def OpenText(txt_file='play_list.txt',output='E:/MyDLMedia'):
    '''
   :param txt_file: file with url line by line to download
   :param output: folder where to save the files
   :return:
    '''

    list2DL= []
    f=open(txt_file,"r")

    for line in f:
        print(line)
        list2DL.append(line)
    DownloadFunction(list2DL,output,False)
    print("Done")

if __name__ == '__main__':
    print('I\'m main')
    OpenText()

