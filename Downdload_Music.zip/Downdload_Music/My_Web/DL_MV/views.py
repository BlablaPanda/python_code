from django.shortcuts import render
from DL_MV.models import MV
from DL_MV.forms import FormToDownload
from My_Web import youtube_download

# Create your views here.
def index(request):
	return render(request,'DL_MV/index.html')

def download(request):
	#mv_list=MV.objects.order_by('author')
	#media_dict={'my_media':mv_list}
	urls=[]
	download_folder="E:\MyDLMedia"
	if_audio=True
	form=FormToDownload()
	if request.method=='POST':
		form=FormToDownload(request.POST)

		if form.is_valid():
			#Do something code
			print("Validated")
			print("url:"+form.cleaned_data['url_todo'])
			urls.append(form.cleaned_data['url_todo'])
			print("url2:"+urls[0])
			print("mode:"+form.cleaned_data['mode'])
			print(download_folder)
			if form.cleaned_data['mode']=='audio':
				if_audio=True
			else:
				if_audio=False
			youtube_download.DownloadFunction(urls,download_folder,if_audio)

			form=FormToDownload()


	return render(request,'DL_MV/download.html',{'form':form})