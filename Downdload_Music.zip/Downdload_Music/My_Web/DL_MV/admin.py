from django.contrib import admin
from DL_MV.models import MV
# Register your models here.
admin.site.register(MV)