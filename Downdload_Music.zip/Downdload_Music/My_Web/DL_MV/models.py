from django.db import models

# Create your models here.

class MV(models.Model):
    url = models.CharField(max_length=256)
    title=models.CharField(max_length=256)
    author=models.CharField(max_length=128)
