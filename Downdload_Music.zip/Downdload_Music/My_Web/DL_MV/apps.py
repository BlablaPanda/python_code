from django.apps import AppConfig


class DlMvConfig(AppConfig):
    name = 'DL_MV'
