from django import forms
from DL_MV.models import MV
from django.core import validators

download_mode=[('audio','audio'),('video','video')]

class FormToDownload(forms.Form):

    #to add check_for http see form validation

    url_todo=forms.URLField(max_length=258)
    #audio_only=forms.BooleanField(initial=True,required=False)
    mode=forms.ChoiceField(choices=download_mode,widget=forms.RadioSelect,initial='audio')

    #To catch robot
    botcatcher=forms.CharField(required=False,widget=forms.HiddenInput)

    def clean_botcatcher(self):
            botcatcher=self.cleaned_data['botcatcher']
            if len(botcatcher)>0:
                raise forms.ValidationError("Gotcha Bot!")
            return botcatcher